package randomwalk;

import java.util.Arrays;

import clustering.*;

public class RandomWalk {

	public static void main(String args[]){
		System.out.println("Let's randomly walk!");
		//KMeans tempMeans = new KMeans("D:/workplace/randomwalk/data/iris.arff");
		//KMeans tempMeans = new KMeans("D:/workspace/randomwalk/data/iris.arff");
		Walk tempWalk = new Walk("D:/workspace/randomwalk/data/iris.arff");
		int[] tempIntArray = {1, 2};
		
		//tempMeans.kMeans(3, KMeans.MANHATTAN);
		//tempMeans.kMeans(3, KMeans.EUCLIDEAN);
		//tempWalk.computeVkS(tempIntArray, 3);
		double[][] tempMatrix = tempWalk.computeTransitionProbabilities();
		double[][] tempTwoStepTransition = Walk.doubleMatricesMultiplex(tempMatrix, tempMatrix);
		System.out.println("The two step transitionProbabilities is: " + Arrays.deepToString(tempTwoStepTransition));
		double[][] tempThreeStepTransition = Walk.doubleMatricesMultiplex(tempTwoStepTransition, tempMatrix);
		System.out.println("The three step transitionProbabilities is: " + Arrays.deepToString(tempThreeStepTransition));
		
		//System.out.println("The accuracy is: " + tempMeans.computePurity());
	}//Of main
}//Of class RandomWalk
