package clustering;

import java.util.Arrays;

public class Walk extends Clustering{
	double[][] weightedGraph = {
			{0, 5, 0, 0, 1},
			{5, 0, 6, 0, 0},
			{0, 6, 0, 0, 0},
			{0, 0, 0, 0, 4},
			{1, 0, 0, 4, 0}
	};
	
	int[][] connections = {
		{0, 1, 0, 0, 1},
		{1, 0, 1, 0, 0},
		{0, 1, 0, 0, 0},
		{0, 0, 0, 0, 1},
		{1, 0, 0, 1, 0}
	};
	
	double[][] transitionProbabilities;
	
	/**
	 *********************
	 * The constructor. Invoke the constructor of the superclass directly.
	 * 
	 * @param paraFilename
	 *            The data filename.
	 *********************
	 */
	public Walk(String paraFilename) {
		super(paraFilename);
	}// of the first constructor

	/**
	 *********************
	 * Multiply two matrices. The number of rows of the second matrix is equal to the number of columns of the first.
	 * 
	 * @param paraMatrix1
	 *            The first matrix.
	 *********************
	 */
	public static int[][] intMatricesMultiplex(int[][] paraMatrix1, int[][] paraMatrix2) {
		int[][] tempResultMatrix = new int[paraMatrix1.length][paraMatrix2[0].length];
		for (int i = 0; i < paraMatrix1.length; i++) {
			for (int j = 0; j < paraMatrix2[0].length; j++) {
				for (int k = 0; k < paraMatrix2.length; k++) {
					tempResultMatrix[i][j] += paraMatrix1[i][k] * paraMatrix2[k][j];
				}//Of for k
			}//Of for k
		}//Of for i
		
		return tempResultMatrix;
	}//of intMatricesMultiplex

	/**
	 *********************
	 * Multiply double two matrices. The number of rows of the second matrix is equal to the number of columns of the first.
	 * 
	 * @param paraMatrix1
	 *            The first matrix.
	 *********************
	 */
	public static double[][] doubleMatricesMultiplex(double[][] paraMatrix1, double[][] paraMatrix2) {
		double[][] tempResultMatrix = new double[paraMatrix1.length][paraMatrix2[0].length];
		for (int i = 0; i < paraMatrix1.length; i++) {
			for (int j = 0; j < paraMatrix2[0].length; j++) {
				for (int k = 0; k < paraMatrix2.length; k++) {
					tempResultMatrix[i][j] += paraMatrix1[i][k] * paraMatrix2[k][j];
				}//Of for k
			}//Of for k
		}//Of for i
		
		return tempResultMatrix;
	}//of doubleMatricesMultiplex

	/**
	 *********************
	 * Multiply two matrices. The number of rows of the second matrix is equal to the number of columns of the first.
	 * 
	 * @param paraMatrix1
	 *            The first matrix.
	 *********************
	 */
	public int[] computeVkS(int[] paraS, int paraK) {
		int[] tempResultSet = new int[weightedGraph.length];
		//Initialization V^0(S)
		for (int i = 0; i < paraS.length; i++) {
			tempResultSet[paraS[i]] = 1;
		}//Of for i
		
		if (paraK < 1) {
			return tempResultSet;
		}//Of if
		
		System.out.println("At the beginning, TempResultSet = " + Arrays.toString(tempResultSet));
		
		//Initialization V^1(S)
		//Add from connections
		for (int i = 0; i < paraS.length; i++) {
			for (int j = 0; j < tempResultSet.length; j++) {
				tempResultSet[j] += connections[paraS[i]][j];
			}//Of for j
		}//Of for i
		System.out.println("k = 1, TempResultSet = " + Arrays.toString(tempResultSet));

		int[][] tempCurrentConnections = connections;
		
		for (int i = 2; i <= paraK; i++) {
			tempCurrentConnections = intMatricesMultiplex(tempCurrentConnections, connections);
			for (int j = 0; j < paraS.length; j++) {
				for (int k = 0; k < tempResultSet.length; k++) {
					tempResultSet[k] += tempCurrentConnections[paraS[j]][k];
				}//Of for j
			}//Of for i
			System.out.println("k = " + i + ", TempResultSet = " + Arrays.toString(tempResultSet));
		}//Of for i

		return tempResultSet;
	}//Of computeVkS

	/**
	 *********************
	 * Compute the transition probabilities
	 * 
	 * @param paraMatrix1
	 *            The first matrix.
	 *********************
	 */
	public double[][] computeTransitionProbabilities() {
		transitionProbabilities = new double[weightedGraph.length][weightedGraph.length];
		double[] tempRowSum = new double[weightedGraph.length];
		for (int i = 0; i < weightedGraph.length; i++) {
			for (int j = 0; j < weightedGraph.length; j++) {
				tempRowSum[i] += weightedGraph[i][j];
			}//Of for j
			
			if (tempRowSum[i] == 0) {
				transitionProbabilities[i][i] = 1;
				continue;
			}//Of if
			
			for (int j = 0; j < weightedGraph.length; j++) {
				transitionProbabilities[i][j] += weightedGraph[i][j]/tempRowSum[i];
			}//Of for j
		}//Of for i
		
		System.out.println("The transitionProbabilities is: " + Arrays.deepToString(transitionProbabilities));
		
		return transitionProbabilities;
	}//Of computeTransitionProbabilities

}//Of class Walk
